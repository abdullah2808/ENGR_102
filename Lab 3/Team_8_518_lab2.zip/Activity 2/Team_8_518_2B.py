# By submitting this assignment, all team members agree to the following:
# # “Aggies do not lie, cheat, or steal, or tolerate those who do”
# # “I have not given or received any unauthorized aid on this assignment”
# #
# # Names: Abdullah Ahmad
# # Raymond Mee
# # Ricky Lee
# # Eric Stevelman
# # Section: 518
# # Assignment: Lab 3 2B
# Date: 16/9/18


from datetime import datetime
current_date_time = str(datetime.now())
print(current_date_time)


