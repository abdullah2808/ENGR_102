# By submitting this assignment, all team members agree to the following:
#  “Aggies do not lie, cheat, or steal, or tolerate those who do”
#  “I have not given or received any unauthorized aid on this assignment”
#
# Names:         Ricky Lee
#                Raymond Mee
#                Eric Srevelman
#                Abdullah Ahmad
# Section:  518
# Assignment: Lab3 Assignment 2-A
# Date:  9/11/2018

a = "Twinkle, twinkle, little star,"
b = "How I wonder what you are!"
c = "Up above the world so high,"
d = "Like a diamond in the sky."
e = '\t'
f = '\n'

print(a + f + e + b + f + e + e + c + f + e + e + d + f + a + f + e + b)
