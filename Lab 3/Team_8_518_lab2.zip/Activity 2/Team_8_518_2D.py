# By submitting this assignment, all team members agree to the following:
#  “Aggies do not lie, cheat, or steal, or tolerate those who do”
#  “I have not given or received any unauthorized aid on this assignment”
#
# Names:         Ricky Lee
#                Raymond Mee
#                Eric Srevelman
#                Abdullah Ahmad
# Section:  518
# Assignment: Lab3 Assignment 2-D
# Date:  9/16/2018
import math
x = float(input("Please enter any number: "))
y = float(input("Please enter any number: "))

print (math.exp(-x))
print (x**y)
print (math.sin(x+y))
print (x/y)
print ((x**2)+(y**2))