# By submitting this assignment, all team members agree to the following:
# # “Aggies do not lie, cheat, or steal, or tolerate those who do”
# # “I have not given or received any unauthorized aid on this assignment”
# #
# # Names: Abdullah Ahmad
# # Raymond Mee
# # Ricky Lee
# # Eric Stevelman
# # Section: 518
# # Assignment: Lab 3 1B
# Date: 16/9/18

BTU = int(input("Please enter British Thermal Units "))
ConvFact = 1055.05585 # 1 BTU = 1055.05585 joules
J = BTU * ConvFact
print (J)