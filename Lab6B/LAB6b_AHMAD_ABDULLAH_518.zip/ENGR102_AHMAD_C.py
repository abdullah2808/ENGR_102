# By submitting this assignment, I agree to the following:
# “Aggies do not lie, cheat, or steal, or tolerate those who do”
# “I have not given or received any unauthorized aid on this assignment”
#
# Name: ABDULLAH AHMAD
# Section: 518
# Assignment: LAB6B-C
# Date: 4 10 2018

for i in range (2,101): #
    for l in range (2, 101):
        if i % l == 0: # checks if the remainder is 0 and if it is then it is divisible by the first #
            print (l, "divides", i)

