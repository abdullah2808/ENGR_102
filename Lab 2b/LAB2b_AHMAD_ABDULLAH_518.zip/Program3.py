# By submitting this assignment, I agree to the following:
# “Aggies do not lie, cheat, or steal, or tolerate those who do”
# “I have not given or received any unauthorized aid on this assignment”
#
# Name: Abdullah Ahmad
# Section: 518
# Assignment: Lab2B-prg3 (e.g. Lab 1b-2)
# Date: 6/9/18

#statements I can use
#x = 1
#y = 10
#z = 0
#x = y
#x += 1
#y += x
#y *= x
#z += x
#z += y
#print (z)

x = 1
z = 0
z += x
print (z)
z += x
z += x
print (z)
z = 0
y = 10
y += x
z += y
print (z)
z += y
z += x
z += x
z += x
z += x
z += x
z += x
print(z)
z = 0
y = 10
x = y
y *= x
z += y
y = 10
x = 1
x += 1
y *= x
z += y
x += 1
z += x
print (z)
z = 0
y = 10
x = y
y *= x #100
x = y #100
y *= x #10000
x = y #10000
y *= x #100000000
x = y #100000000
y *= x # 10000000000000000
x = y
y *= x
z += y
print (z)
y = 10
z = 0
x = y
y *= x
y *= x
x = 1
x += 1
x += 1
x += 1
y *= x
z += y
y = 10
x = y
y *= x
x = 1
x += 1
x += 1
y *= x
z += y
y = 10
x = 1
x += 1
y *= x
z += y
x = 1
z += x
print (z)