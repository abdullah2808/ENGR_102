# By submitting this assignment, I agree to the following:
# “Aggies do not lie, cheat, or steal, or tolerate those who do”
# “I have not given or received any unauthorized aid on this assignment”
#
# Name: Abdullah Ahmad
# Section: 518
# Assignment: Lab2B-prg2B (e.g. Lab 1b-2)
# Date: 6/9/18

# Defining Variables
time1 = 13
X1 = 1
Y1 = 3
Z1 = 7

time2 = 80
X2 = 23
Y2 = -5
Z2 = 10

NewTime = 50

# Finding Slopes

XSlope = (X2-X1)/(time2-time1)
YSlope = (Y2-Y1)/(time2-time1)
ZSlope = (Z2-Z1)/(time2-time1)
# Finding Intercepts

Xintercept =  X1 - (time1 * XSlope)
Yintercept =  Y1 - (time1 * YSlope)
Zintercept =  Z1 - (time1 * ZSlope)
# Finding New Posistions

X3 = NewTime * XSlope + Xintercept
Y3 = NewTime * YSlope + Yintercept
Z3 = NewTime * ZSlope + Zintercept
print ("When the time is 50")
print ("The X Position is", X3)
print ("The Y Position is", Y3)
print ("The Z Position is", Z3)
print ("--------------------")

# With 51

NewTime = 51
X3 = NewTime * XSlope + Xintercept
Y3 = NewTime * YSlope + Yintercept
Z3 = NewTime * ZSlope + Zintercept
print ("When the time is 51")
print ("The X Position is", X3)
print ("The Y Position is", Y3)
print ("The Z Position is", Z3)
print ("--------------------")

# With 52

NewTime = 52
X3 = NewTime * XSlope + Xintercept
Y3 = NewTime * YSlope + Yintercept
Z3 = NewTime * ZSlope + Zintercept
print ("When the time is 52")
print ("The X Position is", X3)
print ("The Y Position is", Y3)
print ("The Z Position is", Z3)
print ("--------------------")

# With 53

NewTime = 53
X3 = NewTime * XSlope + Xintercept
Y3 = NewTime * YSlope + Yintercept
Z3 = NewTime * ZSlope + Zintercept
print ("When the time is 53")
print ("The X Position is", X3)
print ("The Y Position is", Y3)
print ("The Z Position is", Z3)
print ("--------------------")

# With 54

NewTime = 54
X3 = NewTime * XSlope + Xintercept
Y3 = NewTime * YSlope + Yintercept
Z3 = NewTime * ZSlope + Zintercept
print ("When the time is 54")
print ("The X Position is", X3)
print ("The Y Position is", Y3)
print ("The Z Position is", Z3)
print ("--------------------")

# With 55

NewTime = 55
X3 = NewTime * XSlope + Xintercept
Y3 = NewTime * YSlope + Yintercept
Z3 = NewTime * ZSlope + Zintercept
print ("When the time is 55")
print ("The X Position is", X3)
print ("The Y Position is", Y3)
print ("The Z Position is", Z3)
print ("--------------------")