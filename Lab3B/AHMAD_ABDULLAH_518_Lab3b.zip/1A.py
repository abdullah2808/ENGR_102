# By submitting this assignment, I agree to the following:
# “Aggies do not lie, cheat, or steal, or tolerate those who do”
# “I have not given or received any unauthorized aid on this assignment”
#
# Name: ABDULLAH AHMAD
# Section: 518
# Assignment: LAB 3B - 1A
# Date: 13/9/18

mass = int(input("Please enter the mass of an object: "))
velocity = int(input("Please enter the velocity of an object: "))
Kinetic = (((mass)*(velocity**2))/2)
print ("The kinetic energy of the object is ", Kinetic, "with a mass of", mass, "and with a velocity of", velocity) # KINETIC ENERGY
