# By submitting this assignment, all team members agree to the following:
# “Aggies do not lie, cheat, or steal, or tolerate those who do”
# “I have not given or received any unauthorized aid on this assignment”
#
# Names: ABDULALH AHMAD
# AARON EHMRY
# ERIC STEVELMAN
# HARLEY ULLRICH
# Section: 518
# Assignment: WEEK 7 THURSDAY ACTIVITIES
# Date: 11 / 10 / 2018
number_list = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 200, 1234123, 12352345234, 23]
bignumber = sorted(number_list)[-2]
print(bignumber)